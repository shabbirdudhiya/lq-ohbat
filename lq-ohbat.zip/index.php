<?php
require_once '../session.php';
require_once '../requires_login.php';

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/bottom-navbar.css">
    <link rel="stylesheet" href="assets/css/stepper.css">
    <!--  -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script src="assets/js/gtag.js"></script>
    <style type="text/css">
        .box {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: ffffff;
            background-clip: border-box;
            border: 1px solid rgba(0, 0, 0, .125);
            border-radius: 0.25rem;
        }

        /* .card-title {
            font-size: 20px;
        } */
    </style>
    <title>LQ- Ohbat</title>
</head>

<body>
    <!-- MODAL -->
    <section class="modal-section">

        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" id="btn-modal" style="display: none;" data-bs-toggle="modal"
            data-bs-target="#exampleModal"></button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Lailatul Qadar</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <h5>
                            I am a:
                        </h5>
                        <center>
                            <button type="button" id="male" class="btn btn-info">Mard</button>
                            <button type="button" id="female" class="btn btn-info">Bairo</button>
                        </center>
                    </div>
                    <div class="modal-footer">
                        <button type="button" style="display: none;" class="btn btn-secondary" id="btn-close-modal"
                            data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Model end -->
    <section class="main">
        <section class="float-section">
            <div class="container mt-3">
                <div class="d-flex justify-content-evenly">
                    <p class="arabic-text-heading text-center mx-auto"> اهبة ليلة القدر </p>
                    <!-- <button class="btn btn-1 btn-sm mx-1 rounded"> -->
                    <a href="settings.html">
                        <img src="assets/svg/settings_black_24dp.svg" class="my-float" alt="" srcset="">
                    </a>
                    <!-- </button> -->
                </div>
            </div>
        </section>

        <section class="jumbotron-section" style="display: none;">
            <div class="container">
                <div class="mt-4 p-5 bg-light border text-dark rounded">
                    <h1>Mubarak!</h1>
                    <p>
                        Your name has been registered for araz in Hadrat Aaliyah.
                    </p>
                </div>
            </div>
            <br>
        </section>


        <!-- Stepper Start -->
        <section class="stepper">
            <div class="container my-2">
                <div class="box">
                    <div class="card-header">
                        Steps
                    </div>
                    <div class="card-body">
                        <!-- Stepper HTML -->
                        <div class="step step1 step-active">
                            <div>
                                <div class="circle">1<i class="fa fa-check"></i></div>
                            </div>
                            <div>
                                <div class="card-title">
                                    <a href="" class="libas-a-href"> Libas</a>
                                </div>
                                <div class="caption">
                                    <div class="progress my-1 mx-1 menprogressbar" style="height: 20px;">
                                        <div class="progress-bar progress-bgressbar" id="men-apperal-progress-bar"
                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                        </div>
                                    </div>
                                    <div class="progress my-1 mx-1 womenprogressbar" style="height: 20px;">
                                        <div class="progress-bar bg-danger  role=" progressbar"
                                            id="women-apperal-progress-bar" aria-valuenow="25" aria-valuemin="0"
                                            aria-valuemax="100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="step step2">
                            <div>
                                <div class="circle">2</div>
                            </div>
                            <div>
                                <div class="card-title"><a href="instructions.html">Amal Shakelat </a></div>
                                <div class="caption">
                                    <div class="progress my-1 mx-1" style="height: 20px;">
                                        <div class="progress-bar bg-warning" role="progressbar" id="quiz-progress-bar"
                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="step step3">
                            <div>
                                <div class="circle">3</div>
                            </div>
                            <div>
                                <div class="card-title"><a href="kit.html"> Jholnu </a></div>
                                <div class="caption">
                                    <div class="progress my-1 mx-1" style="height: 20px;">
                                        <div class="progress-bar bg-success" role="progressbar" id="kit-progress-bar"
                                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="step step4">
                            <div>
                                <div class="circle">4</div>
                            </div>
                            <div>
                                <div class="card-title"><a href="tasbeeh.html"> Tasbeeh </a></div>
                                <div class="caption">
                                    Finish Activity
                                </div>
                            </div>
                        </div>

                        <div class="step step5">
                            <div>
                                <div class="circle">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="white"
                                        class="bi bi-check-all mx-auto m-1" viewBox="0 0 16 16">
                                        <path
                                            d="M8.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L2.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093L8.95 4.992a.252.252 0 0 1 .02-.022zm-.92 5.14.92.92a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 1 0-1.091-1.028L9.477 9.417l-.485-.486-.943 1.179z" />
                                    </svg>
                                </div>
                            </div>
                            <div>
                                <div class="card-title">Finish</div>
                                <div class="caption">
                                    Mubarak you are ready for Lailatul Qadr
                                </div>
                            </div>
                        </div>
                        <!-- End Stepper HTML -->
                    </div>
                </div>
        </section>

        <!-- Stepper End -->

        <br />
        <section class="bottom-navbar-section">
            <nav class="nav">
                <a href="index.php" class="nav__link  nav__link--active">
                    <img src="assets/svg/dashboard_black_24dp.svg" class="nav__icon  nav__link--active" alt=""
                        srcset="">
                    <span class="nav__text">Dashboard</span>
                </a>
                <a href="apparels-men.html" class="nav__link" id="men-apparel-link">
                    <img src="assets/svg/man_black_24dp.svg" class="nav__icon" alt="">
                    <span class="nav__text">Mard</span>
                </a>
                <a href="apparels-women.html" class="nav__link" id="women-apparel-link">
                    <img src="assets/svg/girl.svg" class="nav__icon" alt="">
                    <span class="nav__text">Bairo</span>
                </a>
                <a href="kit.html" class="nav__link">
                    <img src="assets/svg/shopping_bag_black_24dp.svg" alt="" srcset="">
                    <span class="nav__text">Jholnu</span>
                </a>
                <a href="instructions.html" class="nav__link">
                    <img src="assets/svg/assignment_black_24dp.svg" alt="" srcset="">
                    <span class="nav__text">Amal</span>
                </a>
                <a href="tasbeeh.html" class="nav__link">
                    <img src="assets/svg/filter_vintage_black_24dp.svg" alt="" srcset="">
                    <span class="nav__text">Tasbeeh</span>
                </a>
            </nav>
        </section>
    </section>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(window).on('load', function () {
            if (localStorage.getItem('showModal') == 'true') {
                document.getElementById('btn-modal').click()
                document.getElementById('btn-modal').click()
            } else {
                console.log('Gender selected');
            }
        });
    </script>
    <script src="assets/js/index.js"></script>
    <script src="assets/js/save-its.js"></script>
    <script src="assets/js/stepper.js"></script>
    <script src="assets/js/toggle-full-screen.js"></script>
    <script src="assets/js/gender.js"></script>

</body>

</html>